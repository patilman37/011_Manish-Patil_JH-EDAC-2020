package in.edac.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import in.edac.SeatMeal;
import in.edac.BusDetail;

public interface SeatMealRepository  extends JpaRepository<SeatMeal,Integer> {

	@Query("select s from SeatMeal s where seatNo=?1")
	SeatMeal findById(String seatNo);

	@Query("select s from SeatMeal s where Id=?1")
	SeatMeal findByBusId(BusDetail busDetail);
}