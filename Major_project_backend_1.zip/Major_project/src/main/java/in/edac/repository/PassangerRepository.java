package in.edac.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import in.edac.Passanger;

public interface PassangerRepository  extends JpaRepository<Passanger,Integer> {

	@Query("select s from Passanger s where seatNo=?1 and firstName=?2")
	Passanger findBySeatNoAndFirstName(String seatNo, String firstName);

	//boolean findByEmailIdAndMobile(String emailId, String userName);

}
