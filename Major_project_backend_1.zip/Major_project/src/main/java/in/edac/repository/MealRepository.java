package in.edac.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import in.edac.Mealdetail;
import in.edac.BusDetail;

public interface MealRepository  extends JpaRepository<Mealdetail,Integer> {

	@Query("select s from SeatMeal s where seatNo=?1")
	Mealdetail findById(String seatNo);

	@Query("select s from BusDetail s where Id=?1")
	BusDetail findByBusId(BusDetail busDetail);
}
