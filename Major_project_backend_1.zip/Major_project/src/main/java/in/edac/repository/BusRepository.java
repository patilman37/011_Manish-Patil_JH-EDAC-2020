package in.edac.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import in.edac.BusDetail;

public interface BusRepository  extends JpaRepository<BusDetail,Integer> {

	@Query("select s from BusDetail s where startingPoint=?1 and endingPoint=?2")
	BusDetail searchusing(String startingPoint, String endingPoint);
 
	@Query("select s from BusDetail s where busId=?1")
	BusDetail findByBusId(String bus_id);

}
