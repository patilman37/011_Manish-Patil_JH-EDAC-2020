package in.edac.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import in.edac.SeatMeal;
import in.edac.repository.SeatMealRepository;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/seatmeal")
public class SeaatMealController {
	
	@Autowired
	private SeatMealRepository userRepository;
	
	@PostMapping("/meal")
	
	public boolean register (@RequestBody SeatMeal user)
	{
		try {
			if(findUser(user.getSeatNo()))
				{
					return false;
				}
				else {
					userRepository.save(user);
					 return true;
		}
	}
		catch(Exception e) {
			e.printStackTrace();
			return false;
			
	}
}

	
	
//@PostMapping("/book")
//	
//	public SeatMeal login(@RequestBody SeatMeal user)
//	{
//
//	SeatMeal userdata = userRepository.findByBusId(user.getBusId());
//		
//		if(userdata!=null)
//		{
//			return userdata;
//		}
//		
//		else
//		{
//			return null;
//		}
//	}

public boolean findUser(String seatNo)
{
	List<SeatMeal> list = readAll();
	boolean data=false;
	for(SeatMeal user:list)
	{
		if(user.getSeatNo().equals(seatNo))
		{
			data = true;
			break;
		}
		
	}
	if(data==true)
	{
		return true;
	}
	else
	{
		return false;
	}
}
public List<SeatMeal> readAll(){
	return userRepository.findAll();
}


}
