package in.edac.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.edac.BusDetail;
import in.edac.repository.BusRepository;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/busdetail")
public class BusController {

	@Autowired
	private BusRepository busRepository;

	@PostMapping("/register")

	public boolean register(@RequestBody BusDetail busdetail) {
		try {
			if (findBus(busdetail.getStartingPoint(), busdetail.getEndingPoint())) {
				return false;
			} else {
				busRepository.save(busdetail);
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;

		}
	}

	@PostMapping("/search")

	public BusDetail login(@RequestBody BusDetail user) {

		BusDetail userdata = busRepository.searchusing(user.getStartingPoint(), user.getEndingPoint());
		System.out.println("busdetails " + userdata);
		if (userdata != null) {
			return userdata;
		}

		else {
			return null;
		}

	}

	public boolean findBus(String startingPoint, String endingPoint) {
		List<BusDetail> list = readAll();
		boolean data = false;
		for (BusDetail user : list) {
			if (user.getStartingPoint().equalsIgnoreCase(startingPoint) || user.getEndingPoint().equals(endingPoint)) {
				data = true;
				break;
			}

		}
		if (data == true) {
			return true;
		} else {
			return false;
		}
	}

	public List<BusDetail> readAll() {
		return busRepository.findAll();
	}

}
