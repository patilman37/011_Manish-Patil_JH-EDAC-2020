package in.edac.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import in.edac.Passanger;
import in.edac.repository.PassangerRepository;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/passanger")
public class PassangerController {

	@Autowired
	private PassangerRepository userRepository;
	
	@PostMapping("/detail")
	
	public boolean register (@RequestBody Passanger user)
	{
		try {
			if(findUser(user.getSeatNo(),user.getFirstName()))
				{
					return false;
				}
				else {
					userRepository.save(user);
					 return true;
		}
	}
		catch(Exception e) {
			e.printStackTrace();
			return false;
			
	}
}

public boolean findUser(String seatNo, String firstName)
{
	List<Passanger> list = readAll();
	boolean data=false;
	for(Passanger user:list)
	{
		if(user.getSeatNo().equalsIgnoreCase(seatNo) || user.getFirstName().equals(firstName))
		{
			data = true;
			break;
		}
		
	}
	if(data==true)
	{
		return true;
	}
	else
	{
		return false;
	}
}
public List<Passanger> readAll(){
	return userRepository.findAll();
}

	
}
