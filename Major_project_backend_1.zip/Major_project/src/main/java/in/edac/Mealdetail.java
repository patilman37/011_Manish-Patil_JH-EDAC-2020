package in.edac;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Mealdetail {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int mealIid;	
	private String foodItem;
	private String specialItem;
	private String foodQuatity;
	private String deliveryType;
	
	public Mealdetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Mealdetail(String foodItem, String specialItem, String foodQuatity,String deliveryType) {
		super();
		this.foodItem = foodItem;
		this.specialItem = specialItem;
		this.foodQuatity = foodQuatity;
		this.deliveryType = deliveryType;

	}

	public int getMealIid() {
		return mealIid;
	}

	public void setMealIid(int mealIid) {
		this.mealIid = mealIid;
	}

	public String getFoodItem() {
		return foodItem;
	}

	public void setFoodItem(String foodItem) {
		this.foodItem = foodItem;
	}

	public String getSpecialItem() {
		return specialItem;
	}

	public void setSpecialItem(String specialItem) {
		this.specialItem = specialItem;
	}

	public String getFoodQuatity() {
		return foodQuatity;
	}

	public void setFoodQuatity(String foodQuatity) {
		this.foodQuatity = foodQuatity;
	}

	public String getDeliveryType() {
		return deliveryType;
	}

	public void setDeliveryType(String deliveryType) {
		this.deliveryType = deliveryType;
	}
	
	

}
