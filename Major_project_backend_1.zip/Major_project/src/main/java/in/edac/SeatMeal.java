package in.edac;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;


@Entity
public class SeatMeal {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int seat_id;
	private String seatNo;
	
//	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "cart")
//	private User user; // cart

//	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//	@JoinColumn(name = "cart_id")
//	private Cart cart; // foreign k

	
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name="busId")
	private BusDetail bus_id;
	
//	public BusDetail getBusId() {
//		return bus_id;
//	}
//	public void setBusId(BusDetail bus_id) {
//		this.bus_id = bus_id;
//	}
	public SeatMeal() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SeatMeal(String seatNo) {
		super();
		this.seatNo = seatNo;
	}
	public int getSeat_id() {
		return seat_id;
	}
	public void setSeat_id(int seat_id) {
		this.seat_id = seat_id;
	}
	public String getSeatNo() {
		return seatNo;
	}
	public void setSeatNo(String seatNo) {
		this.seatNo = seatNo;
	}
		
}
