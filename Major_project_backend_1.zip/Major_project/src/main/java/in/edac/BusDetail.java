package in.edac;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;


@Entity
public class BusDetail {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="busId")
	private int bus_id;
	private String busName;
	private String seatingCapacity;
	private String busType;
	private String startingPoint;
	private String endingPoint;
	private String busNo;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "bus_id")
	private SeatMeal seatMeal;
	
	public BusDetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public BusDetail(String busName, String seatingCapacity, String busType, String startingPoint,String endingPoint, String busNo) {
		super();
		this.busName = busName;
		this.seatingCapacity = seatingCapacity;
		this.busType = busType;
		this.startingPoint = startingPoint;
		this.endingPoint = endingPoint;
		this.busNo = busNo;


	}
	
	
	
	//Getters and Setters
	public int getId() {
		return bus_id;
	}
	public void setId(int bus_id) {
		this.bus_id = bus_id;
	}
	public String getBusName() {
		return busName;
	}
	public void setBusName(String busName) {
		this.busName = busName;
	}
	public String getSeatingCapacity() {
		return seatingCapacity;
	}
	public void setSeatingCapacity(String seatingCapacity) {
		this.seatingCapacity = seatingCapacity;
	}
	public String getBusType() {
		return busType;
	}
	public void setBusType(String busType) {
		this.busType = busType;
	}
	public String getStartingPoint() {
		return startingPoint;
	}
	public void setStartingPoint(String startingPoint) {
		this.startingPoint = startingPoint;
	}
	public String getEndingPoint() {
		return endingPoint;
	}
	public void setEndingPoint(String endingPoint) {
		this.endingPoint = endingPoint;
	}
	
	public String getBusNo() {
		return busNo;
	}
	public void setBusNo(String busNo) {
		this.busNo = busNo;
	}
	@Override
	public String toString() {
		return "BusDetail [bus_id=" + bus_id + ", busName=" + busName + ", seatingCapacity=" + seatingCapacity
				+ ", busType=" + busType + ", startingPoint=" + startingPoint + ", endingPoint=" + endingPoint
				+ ", busNo=" + busNo + "]";
	}
	
}
