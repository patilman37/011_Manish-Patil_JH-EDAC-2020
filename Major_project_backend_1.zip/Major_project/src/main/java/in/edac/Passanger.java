package in.edac;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Passanger {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int pasId;
	private String seatNo;
	private String firstName;
	private String lastName;
	private String gender;
	private String pickUpPoint;
	private String dropPoint;
	private String address;
	private String mobileNo;
	private String date;
	
	public Passanger() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Passanger(String seatNo, String firstName, String lastName, String pickUpPoint,String dropPoint, String gender, String address,String mobileNo) {
		super();
		this.seatNo = seatNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.address = address;
		this.mobileNo = mobileNo;
		this.pickUpPoint=pickUpPoint;
		this.dropPoint=dropPoint;
	}

	public int getPasId() {
		return pasId;
	}

	public void setPasId(int pasId) {
		this.pasId = pasId;
	}

	public String getSeatNo() {
		return seatNo;
	}

	public void setSeatNo(String seatNo) {
		this.seatNo = seatNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getPickUpPoint() {
		return pickUpPoint;
	}

	public void setPickUpPoint(String pickUpPoint) {
		this.pickUpPoint = pickUpPoint;
	}

	public String getDropPoint() {
		return dropPoint;
	}

	public void setDropPoint(String dropPoint) {
		this.dropPoint = dropPoint;
	}
	
	
	
}
